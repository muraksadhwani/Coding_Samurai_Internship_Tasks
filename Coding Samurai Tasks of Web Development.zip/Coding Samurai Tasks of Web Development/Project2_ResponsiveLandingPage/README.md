# Responsive Landing Page

This project is a beginner-friendly **responsive landing page** created for a fictional product or service.

---

## 📋 Description

The landing page is designed with a clean, modern layout. It adapts beautifully to all screen sizes using **CSS Flexbox**, **Grid**, and **media queries**.

---

## 💡 What You Learn

- Responsive web design (media queries)
- CSS Flexbox and Grid layout systems
- Mobile-first UI development
- Simple HTML structure and form integration

---

## 📁 Project Files

```
responsive-landing-page/
├── index.html       # The main HTML file
├── style.css        # CSS styles with Flexbox and responsiveness
└── README.md        # Project documentation and setup guide
```

---

## 💻 How to Run

1. Download the project folder.
2. Open `index.html` using any modern web browser.
3. Try resizing the window to see how the layout responds.

---

## 🧠 Bonus

You can expand this by:
- Adding animations with CSS
- Connecting the form to a backend (like Firebase or Google Forms)
- Adding product images or testimonials

---

## 📬 Contact

**Murak Sadhwani**  
Email: muraksadhwani.cs23@gmail.com  
LinkedIn: [Visit Profile](https://www.linkedin.com/in/murak-sadhwani-310528272)

Enjoy learning and happy coding! 🚀