function showMessage() {
    alert("Thankyou so much for visiting on my site. Feel free to connect.");
}