# Personal Portfolio Website

This is a simple personal portfolio website built using HTML, CSS, and basic JavaScript. 
The project is designed for beginner-level developers to practice foundational web development skills.

## ✨ Features

- **About Me** section – Introduction about yourself
- **Projects** section – Showcase of your work
- **Contact** section – A button that shows an alert message when clicked

## 🛠️ Technologies Used

- HTML for structure
- CSS for styling and layout
- JavaScript for basic interactivity

## Structure

```
PersonalPortfolio/
│
├── index.html       → Main web page
├── style.css        → CSS styles
├── script.js        → JavaScript file for alert button
└── README.txt       → This instruction file
```

##  Learning Objectives

- Understand HTML structure (header, section, nav, etc.)
- Apply basic CSS for styling
- Use simple JavaScript to add interactivity

You can also run this project using **VS Code + Live Server** or host it online using **GitHub Pages**.
